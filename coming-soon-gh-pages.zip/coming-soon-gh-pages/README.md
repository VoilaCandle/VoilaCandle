Coming Soon
===========
Coming Soon is a simplistic, animated and responsive "coming soon" page.

- HTML and CSS
- Multi-Browser Support (Up to Date Major Browsers)
- Responsive Design

[Demo](http://yc.github.io/coming-soon/)
<img src="index.svg" width="960" height="540" />
